FITFORGE GYM WEBSITE
====================

1. Upload the entire folder to your web host.
2. Keep the folder structure unchanged.
3. Replace YOUR-DOMAIN.example in robots.txt and sitemap.xml with your real domain.
4. Replace the starter legal pages with information that accurately describes your site and practices.
5. Connect the contact form to a real form/email service.
6. Add original images or keep the image URLs only if your hosting/usage setup permits them.
7. Add Google Search Console and submit sitemap.xml after the site is live.
8. Apply for AdSense when the site has substantial original content and meets Google's current policies.
9. After approval, put your actual AdSense publisher code in the appropriate ad placements and your real publisher line in ads.txt.

The 24 articles are intentionally starter editorial templates. Expand, fact-check, edit, and personalize them before publishing.
